package org.jfugue.pattern;

import java.util.List;

import org.jfugue.theory.Note;

public interface NotesProducer {
    public List<Note> getNotes();
}
